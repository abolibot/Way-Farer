/* eslint-env node, mocha */
/* eslint-disable prefer-arrow-callback */
/* eslint-disable func-names */
import chai from 'chai';
import chaiHttp from 'chai-http';

import app from '../../server/server';
import signinData from '../../server/helpers/testData/signin';

chai.use(chaiHttp);
chai.should();

describe('POST /api/v1/auth/signin', function () {
  it('should return \'"email" is required\' message when email is omitted in request', function () {
    chai.request(app)
      .post('/api/v1/auth/signin')
      .send(signinData.scenarios.withoutEmail)
      .end(function (err, res) {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"email" is required');
      });
  });

  it('should return \'"email" must be a valid email\' message when req.email is not a valid email', function () {
    chai.request(app)
      .post('/api/v1/auth/signin')
      .send(signinData.scenarios.withInvalidEmail)
      .end(function (err, res) {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"email" must be a valid email');
      });
  });

  it('should return \'"password" is required\' message when password is omitted in request', function () {
    chai.request(app)
      .post('/api/v1/auth/signin')
      .send(signinData.scenarios.withoutPassword)
      .end(function (err, res) {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"password" is required');
      });
  });

  it('should return \'"password" length must be at least 6 characters long\' message when req.password is not a valid password', function () {
    chai.request(app)
      .post('/api/v1/auth/signin')
      .send(signinData.scenarios.withInvalidPassword)
      .end(function (err, res) {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"password" length must be at least 6 characters long');
      });
  });

  it('email doesn\'t exist', function (done) {
    chai.request(app)
      .post('/api/v1/auth/signin')
      .send({
        email: 'existingemail@gmail.com',
        password: signinData.users[0].password,
      })
      .end(function (err, res) {
        console.log('email doesn\'t exist');
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('invalid login details');
        done(err);
      });
  });

  it('incorrect password', function (done) {
    chai.request(app)
      .post('/api/v1/auth/signin')
      .send({
        email: signinData.users[0].email,
        password: `${signinData.users[0].password}abah`,
      })
      .then(function (res) {
        console.log('incorrect password');
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('invalid login details');
        done();
      })
      .catch(err => done(err));
  });

  it('authentication passed', function (done) {
    chai.request(app)
      .post('/api/v1/auth/signin')
      .send({
        email: signinData.users[0].email,
        password: signinData.users[0].password,
      })
      .then(function (res) {
        console.log('authentication passed');
        res.status.should.be.equal(200);
        res.body.should.have.property('status');
        res.body.should.have.property('message');
        res.body.should.have.property('data');
        res.body.message.should.equal('user signin successful');
        res.body.status.should.equal(200);
        res.body.data.should.be.an('object');
        res.body.data.should.have.a.property('user_id');
        res.body.data.should.have.a.property('is_admin');
        res.body.data.should.have.a.property('token');
      })
      .catch(err => done(err));
  });
});
