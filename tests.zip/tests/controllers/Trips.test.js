/* eslint-env node, mocha */
import chai from 'chai';
import chaiHttp from 'chai-http';

import app from '../../server/server';
import tripsData from '../../server/helpers/testData/trips';
import { getToday, getNextSevenDays } from '../../server/helpers/getDates';
import generateToken from '../../server/helpers/tokenGeneration';

chai.use(chaiHttp);
chai.should();

const { getAllTripsData, createTripData } = tripsData;

describe('GET /api/v1/trips', () => {
  it('should return \'"user_id" is required\' message when user_id is omitted in request', (done) => {
    chai.request(app)
      .get('/api/v1/trips')
      .send(getAllTripsData.scenarios.withoutUserId)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"user_id" is required');
        done(err);
      });
  });

  it('should return \'"user_id" must be a number\' message when req.user_id is not a number', (done) => {
    chai.request(app)
      .get('/api/v1/trips')
      .send(getAllTripsData.scenarios.withInvalidUserId)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"user_id" must be a number');
        done(err);
      });
  });

  it('should return \'"user_id" must be larger than or equal to 1\' message when req.user_id is zero', (done) => {
    chai.request(app)
      .get('/api/v1/trips')
      .send(getAllTripsData.scenarios.withZeroAsUserId)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"user_id" must be larger than or equal to 1');
        done(err);
      });
  });

  it('should return \'"is_admin" is required\' message when is_admin is omitted in request', (done) => {
    chai.request(app)
      .get('/api/v1/trips')
      .send(getAllTripsData.scenarios.withoutIsAdmin)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"is_admin" is required');
        done(err);
      });
  });

  it('should return \'"is_admin" must be a boolean\' message when req.is_admin is not a valid is_admin', (done) => {
    chai.request(app)
      .get('/api/v1/trips')
      .send(getAllTripsData.scenarios.withInvalidIsAdmin)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"is_admin" must be a boolean');
        done(err);
      });
  });

  it('should return \'You need a token to access this route\' message when req.headers.authorization is undefined', (done) => {
    chai.request(app)
      .get('/api/v1/trips')
      .send(getAllTripsData.scenarios.withUndefinedReqHeadersAuthorization)
      .end((err, res) => {
        res.status.should.be.equal(401);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(401);
        res.body.error.should.equal('You need a token to access this route');
        done(err);
      });
  });

  it('should return \'invalid token\' message when there is an error validating token', (done) => {
    chai.request(app)
      .get('/api/v1/trips')
      .set('Authorization', `Bearer ${generateToken(createTripData.validUser)}`)
      .send(getAllTripsData.scenarios.withInvalidToken)
      .end((err, res) => {
        console.log(res.body);
        res.status.should.be.equal(401);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(401);
        res.body.error.should.equal('invalid token');
        done(err);
      });
  });

  it('should return all trips on sucessful authentication', (done) => {
    chai.request(app)
      .get('/api/v1/trips')
      .set('Authorization', `Bearer ${generateToken(createTripData.validUser)}`)
      .send(getAllTripsData.scenarios.withUserAuthenticated)
      .end((err, res) => {
        res.status.should.be.equal(200);
        res.body.should.have.property('status');
        res.body.should.have.property('count');
        res.body.should.have.property('data');
        res.body.count.should.a('number');
        res.body.status.should.equal(200);
        res.body.data.should.be.an('array');
        done(err);
      });
  });
});

describe('POST /api/v1/trips', () => {
  it('should return \'"user_id" is required\' message when user_id is omitted in request', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withoutUserId)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"user_id" is required');
        done(err);
      });
  });

  it('should return \'"user_id" must be a number\' message when req.user_id is not a number', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withInvalidUserId)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"user_id" must be a number');
        done(err);
      });
  });

  it('should return \'"user_id" must be larger than or equal to 1\' message when req.user_id is zero', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withZeroAsUserId)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"user_id" must be larger than or equal to 1');
        done(err);
      });
  });

  it('should return \'"is_admin" is required\' message when is_admin is omitted in request', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withoutIsAdmin)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"is_admin" is required');
        done(err);
      });
  });

  it('should return \'"is_admin" must be a boolean\' message when req.is_admin is not a valid is_admin', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withInvalidIsAdmin)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"is_admin" must be a boolean');
        done(err);
      });
  });

  it('should return \'"bus_id" is required\' message when bus_id is omitted in request', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withoutBusId)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"bus_id" is required');
        done(err);
      });
  });

  it('should return \'"bus_id" must be a number\' message when req.bus_id is not a number', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withInvalidBusId)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"bus_id" must be a number');
        done(err);
      });
  });

  it('should return \'"bus_id" must be larger than or equal to 1\' message when req.bus_id is zero', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withZeroAsBusId)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"bus_id" must be larger than or equal to 1');
        done(err);
      });
  });

  it('should return \'"origin" is required\' message when origin is omitted in request', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withoutOrigin)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"origin" is required');
        done(err);
      });
  });

  it('should return \'\' message when req.origin is not of the required format', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withInvalidOrigin)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal(`"origin" with value "${createTripData.scenarios.withInvalidOrigin.origin}" fails to match the required pattern: /^([a-zA-Z0-9]{2,30}[- ]{0,1}[a-zA-Z0-9]{2,30})$/`);
        done(err);
      });
  });

  it('should return \'"destination" is required\' message when destination is omitted in request', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withoutDestination)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"destination" is required');
        done(err);
      });
  });

  it('should return \'\' message when req.destination is not of the required format', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withInvalidDestination)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal(`"destination" with value "${createTripData.scenarios.withInvalidDestination.destination}" fails to match the required pattern: /^([a-zA-Z0-9]{2,30}[- ]{0,1}[a-zA-Z0-9]{2,30})$/`);
        done(err);
      });
  });

  it('should return \'"trip_date" is required\' message when trip_date is omitted in request', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withoutTripDate)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"trip_date" is required');
        done(err);
      });
  });

  it(`should return "trip_date" must be larger than or equal to ${getToday()} message when req.trip_date is on or before today`, (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withTripDateBeforeToday)
      .end((err, res) => {
        console.log(res.body);
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal(`"trip_date" must be larger than or equal to "${getToday()}"`);
        done(err);
      });
  });

  it(`should return "trip_date" must be less than or equal to ${getNextSevenDays()} message when req.trip_date is more than seven days from today`, (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withTripDateBeyondSevenDays)
      .end((err, res) => {
        console.log(getNextSevenDays());
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal(`"trip_date" must be less than or equal to "${getNextSevenDays()}"`);
        done(err);
      });
  });

  it('should return \'"trip_date" must be a valid ISO 8601 date\' message when req.trip_date is not a valid date', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withInvalidTripDate)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"trip_date" must be a number of milliseconds or valid date string');
        done(err);
      });
  });

  it('should return \'"fare" is required\' message when fare is omitted in request', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withoutFare)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"fare" is required');
        done(err);
      });
  });

  it('should return \'"fare" must be a number\' message when req.fare is not of the required format', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withInvalidFare)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"fare" must be a number');
        done(err);
      });
  });

  it('should return \'"fare" must be larger than or equal to 1000\' message when req.fare is less than 1000', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withLesserFare)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"fare" must be larger than or equal to 1000');
        done(err);
      });
  });

  it('should return \'"fare" must be smaller than or equal to 15000\' message when req.fare is greater than 15000', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withGreaterFare)
      .end((err, res) => {
        res.status.should.be.equal(400);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(400);
        res.body.error.should.equal('"fare" must be less than or equal to 15000');
        done(err);
      });
  });

  it('should return \'You need a token to access this route\' message when req.headers.authorization is undefined', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .send(createTripData.scenarios.withUndefinedReqHeadersAuthorization)
      .end((err, res) => {
        res.status.should.be.equal(401);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(401);
        res.body.error.should.equal('You need a token to access this route');
        done(err);
      });
  });

  it('should return \'invalid token\' message when there is an error validating token', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .set('Authorization', `Bearer ${generateToken(createTripData.validUser)}`)
      // .set('rows', [createTripData.invalidUser])
      .send(createTripData.scenarios.withInvalidToken)
      .end((err, res) => {
        res.status.should.be.equal(401);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(401);
        res.body.error.should.equal('invalid token');
        done(err);
      });
  });

  it('should return \'invalid token\' message when there is an error processing token', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .set('Authorization', 'Bearer 222')
      .send(createTripData.scenarios.withInvalidToken)
      .end((err, res) => {
        res.status.should.be.equal(500);
        res.body.should.have.property('status');
        res.body.should.have.property('error');
        res.body.status.should.equal(500);
        res.body.error.should.be.an('object');
        done(err);
      });
  });


  it('should return the trip\'s details on sucessful authentication and creation', (done) => {
    chai.request(app)
      .post('/api/v1/trips')
      .set('Authorization', `Bearer ${generateToken(createTripData.validUser)}`)
      .send(createTripData.scenarios.withUserAuthenticated)
      .end((err, res) => {
        console.log(res.body);
        res.status.should.be.equal(201);
        res.body.should.have.property('status');
        res.body.should.have.property('message');
        res.body.should.have.property('data');
        res.body.message.should.equal('trip created successfully');
        res.body.status.should.equal(201);
        res.body.data.should.be.an('object');
        res.body.data.should.have.a.property('trip_id');
        res.body.data.should.have.a.property('bus_id');
        res.body.data.should.have.a.property('origin');
        res.body.data.should.have.a.property('destination');
        res.body.data.should.have.a.property('trip_date');
        res.body.data.should.have.a.property('fare');
        done(err);
      });
  });
});
